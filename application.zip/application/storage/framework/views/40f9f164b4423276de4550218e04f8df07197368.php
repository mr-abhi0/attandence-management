    <?php $__env->startSection('meta'); ?>
        <title>Employees | Workday Time Clock</title>
        <meta name="description" content="Workday view employees, delete employees, edit employees, add employees">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <div class="box box-success col-md-6">
            <div class="box-header with-border"><?php echo e(__('Delete Employee Account')); ?></div>
                <div class="box-body">
                    <form action="<?php echo e(url('profile/delete/employee')); ?>" class="ui form" method="post" accept-charset="utf-8">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php if(isset($id)): ?> <?php echo e($id); ?> <?php endif; ?>">
                        <div class="field">
                            <div class="ui header" style="margin:0"><?php echo e(__('Are you sure you want to delete this!')); ?></div>
                        </div>
                        <div class="field">
                            <p><?php echo e(__("Deleting this account also deletes the following data: Employee's Attendance, Schedules, Leaves, User Account, or All records associated with this Employee.")); ?></p>
                        </div>
                        <div class="field">
                            <a href="<?php echo e(url('employees')); ?>" class="ui black deny button"><?php echo e(__('No')); ?></a>
                            <button class="ui positive button approve" type="submit" name="submit"><i class="ui checkmark icon"></i><?php echo e(__('Yes')); ?></button>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\final\application\resources\views/admin/delete-employee.blade.php ENDPATH**/ ?>