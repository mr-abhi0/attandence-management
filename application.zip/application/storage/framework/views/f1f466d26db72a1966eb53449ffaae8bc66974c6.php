    <?php $__env->startSection('meta'); ?>
        <title>Employees | Workday Time Clock</title>
        <meta name="description" content="Workday employees, view all employees, add, edit, delete, and archive employees.">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title uppercase"><?php echo e(__('Employees')); ?>

                <a class="ui positive button mini offsettop5 float-right" href="<?php echo e(url('employees/new')); ?>"><i class="ui icon plus"></i><?php echo e(__('Add')); ?></a>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "desc" ]]'>
                    <thead>
                        <tr>
                            <th><?php echo e(__('ID')); ?></th> 
                            <th><?php echo e(__('Employee')); ?></th> 
                            <th><?php echo e(__('Company')); ?></th>
                            <th><?php echo e(__('Department')); ?></th>
                            <th><?php echo e(__('Position')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th class=""></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(isset($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="">
                            <td><?php echo e($employee->idno); ?></td>
                            <td><?php echo e($employee->lastname); ?>, <?php echo e($employee->firstname); ?></td>
                            <td><?php echo e($employee->company); ?></td>
                            <td><?php echo e($employee->department); ?></td>
                            <td><?php echo e($employee->jobposition); ?></td>
                            <td><?php if($employee->employmentstatus == 'Active'): ?> Active <?php else: ?> Archived <?php endif; ?></td>
                            <td class="align-right">
                            <a href="<?php echo e(url('/profile/view/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="file alternate outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/edit/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="edit outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/delete/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="trash alternate outline icon"></i></a>
                            <a href="<?php echo e(url('/profile/archive/'.$employee->reference)); ?>" class="ui circular basic icon button tiny"><i class="archive icon"></i></a>
                            </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\att\final\application\resources\views/admin/employees.blade.php ENDPATH**/ ?>