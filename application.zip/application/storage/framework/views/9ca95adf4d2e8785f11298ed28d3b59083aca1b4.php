    <?php $__env->startSection('meta'); ?>
        <title>Schedules | Workday Time Clock</title>
        <meta name="description" content="Workday schedules, view all employee schedules, add schedule or shift, edit, and delete schedules">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/vendor/air-datepicker/dist/css/datepicker.min.css')); ?>" rel="stylesheet">
    <style>
        /* .ui.active.modal {position: relative !important;} */
        .datepicker {z-index: 999 !important;}
        .datepickers-container {z-index: 9999 !important;}
    </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.modals.modal-add-schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__('Schedules')); ?>

                <button class="ui positive button mini offsettop5 btn-add float-right"><i class="ui icon plus"></i><?php echo e(__('Add')); ?></button>
            </h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                    <table width="100%" class="table table-striped table-hover" id="dataTables-example" data-order='[[ 6, "asc" ]]'>
                        <thead>
                            <tr>
                                <th><?php echo e(__('Employee')); ?></th>
                                <th><?php echo e(__('Time (Start-Off)')); ?></th>
                                <th><?php echo e(__('Hours')); ?></th>
                                <th><?php echo e(__('Rest Days')); ?></th>
                                <th><?php echo e(__('From (Date)')); ?></th>
                                <th><?php echo e(__('To (Date)')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(isset($schedules)): ?>
                            <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sched->employee); ?></td>
                                <td>
                                    <?php
                                        if($tf == 1) {
                                            echo e(date("h:i A", strtotime($sched->intime)));
                                            echo " - ";
                                            echo e(date("h:i A", strtotime($sched->outime)));
                                        } else {
                                            echo e(date("H:i", strtotime($sched->intime)));
                                            echo " - ";
                                            echo e(date("H:i", strtotime($sched->outime)));
                                        }
                                    ?>
                                </td>
                                <td><?php echo e($sched->hours); ?> hr</td>
                                <td><?php echo e($sched->restday); ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($sched->datefrom))) ?></td>
                                <td><?php echo e(date('D, M d, Y', strtotime($sched->dateto))) ?></td>
                                <td>
                                    <?php if($sched->archive == '0'): ?> 
                                        <span class="green"><?php echo e(__('Present')); ?></span>
                                    <?php else: ?>
                                        <span class="teal"><?php echo e(__('Previous')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="align-right">
                                    <?php if($sched->archive == '0'): ?> 
                                        <a href="<?php echo e(url('/schedules/edit/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon edit outline"></i></a>
                                        <a href="<?php echo e(url('/schedules/delete/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                        <a href="<?php echo e(url('/schedules/archive/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon archive"></i></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/schedules/delete/'.$sched->id)); ?>" class="ui circular basic icon button tiny"><i class="icon trash alternate outline"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/air-datepicker/dist/js/i18n/datepicker.en.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/vendor/mdtimepicker/mdtimepicker.min.js')); ?>"></script>

    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: true,ordering: true});
    $('.airdatepicker').datepicker({ language: 'en', dateFormat: 'yyyy-mm-dd' });

    <?php if(isset($tf)): ?>
        <?php if($tf == 1): ?>
            $('.jtimepicker').mdtimepicker({format:'h:mm tt', theme: 'blue', hourPadding: true});
        <?php else: ?>
            $('.jtimepicker').mdtimepicker({format:'hh:mm', theme: 'blue', hourPadding: true});
        <?php endif; ?>
    <?php endif; ?>

    $('.ui.dropdown.getid').dropdown({ onChange: function(value, text, $selectedItem) {
        $('select[name="employee"] option').each(function() {
            if($(this).val()==value) {var id = $(this).attr('data-id');$('input[name="id"]').val(id);};
        });
    }});
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\final\application\resources\views/admin/schedules.blade.php ENDPATH**/ ?>