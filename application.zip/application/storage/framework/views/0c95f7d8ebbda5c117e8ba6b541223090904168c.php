    <?php $__env->startSection('meta'); ?>
        <title>Edit User | Workday Time Clock</title>
        <meta name="description" content="Workday edit user.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="page-title"><?php echo e(__("Edit User")); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-content">
                        <?php if($errors->any()): ?>
                        <div class="ui error message">
                            <i class="close icon"></i>
                            <div class="header"><?php echo e(__("There were some errors with your submission")); ?></div>
                            <ul class="list">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <form id="edit_user_form" action="<?php echo e(url('users/update/user')); ?>" class="ui form add-user" method="post" accept-charset="utf-8">
                            <?php echo csrf_field(); ?>
                            <div class="field">
                                <label><?php echo e(__("Employee")); ?></label>
                                <input type="text" name="employee" value="<?php if(isset($u->name)): ?><?php echo e($u->name); ?><?php endif; ?>" class="readonly uppercase" readonly>
                            </div>
                            <div class="field">
                                <label><?php echo e(__("Email")); ?></label>
                                <input type="text" name="email" value="<?php if(isset($u->email)): ?><?php echo e($u->email); ?><?php endif; ?>" class="readonly lowercase" readonly>
                            </div>
                            <div class="grouped fields opt-radio">
                                <label class=""><?php echo e(__("Choose Account type")); ?></label>
                                <div class="field">
                                    <div class="ui radio checkbox">
                                        <input type="radio" name="acc_type" value="1" <?php if(isset($u->acc_type)): ?> <?php if($u->acc_type == 1): ?> checked <?php endif; ?> <?php endif; ?>>
                                        <label><?php echo e(__("Employee")); ?></label>
                                    </div>
                                </div>
                                <div class="field" style="padding:0px!important">
                                    <div class="ui radio checkbox">
                                        <input type="radio" name="acc_type" value="2" <?php if(isset($u->acc_type)): ?> <?php if($u->acc_type == 2): ?> checked <?php endif; ?> <?php endif; ?>>
                                        <label><?php echo e(__("Admin")); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="fields">
                                <div class="sixteen wide field role">
                                    <label for=""><?php echo e(__("Role")); ?></label>
                                    <select class="ui dropdown uppercase" name="role_id">
                                        <option value="">Select Role</option>
                                        <?php if(isset($r)): ?>
                                            <?php $__currentLoopData = $r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>" <?php if($role->id == $u->role_id): ?> selected <?php endif; ?>><?php echo e($role->role_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="field">
                                <label><?php echo e(__("Status")); ?></label>
                                <select class="ui dropdown uppercase" name="status">
                                    <option value="">Select Status</option>
                                    <option value="1" <?php if(isset($u->status)): ?> <?php if($u->status == 1): ?> selected <?php endif; ?> <?php endif; ?>>Enabled</option>
                                    <option value="0" <?php if(isset($u->status)): ?> <?php if($u->status == 0): ?> selected <?php endif; ?> <?php endif; ?>>Disabled</option>
                                </select>
                            </div>
                            <div class="two fields">
                                <div class="field">
                                    <label for=""><?php echo e(__("New Password")); ?></label>
                                    <input type="password" name="password" class="" placeholder="********">
                                </div>
                                <div class="field">
                                    <label for=""><?php echo e(__("Confirm New Password")); ?></label>
                                    <input type="password" name="password_confirmation" class="" placeholder="********">
                                </div>
                            </div>
                            <div class="field">
                                <div class="ui error message">
                                    <i class="close icon"></i>
                                    <div class="header"></div>
                                    <ul class="list">
                                        <li class=""></li>
                                    </ul>
                                </div>
                            </div>
                    </div>

                    <div class="box-footer">
                        <input type="hidden" value="<?php if(isset($e_id)): ?><?php echo e($e_id); ?><?php endif; ?>" name="ref">
                        <button class="ui positive approve small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Update")); ?></button>
                        <a href="<?php echo e(url('users')); ?>" class="ui black grey small button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></a>
                    </div>

                    </form>

                </div>
            </div>
        </div>

        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>
        <script type="text/javascript">
            $(document).ready(function () {
                $('.opt-radio .checkbox').first().checkbox({
                    ischecked: function () {
                        $('.role, .role .ui.dropdown').addClass('disabled');
                        $('select[name="role_id"]').addClass('disabled').val('');
                    }
                });
            });
        </script>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\att\final\application\resources\views/admin/edits/edit-user.blade.php ENDPATH**/ ?>