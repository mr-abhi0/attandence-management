<div class="ui modal medium add">
    <div class="header"><?php echo e(__("Add New User")); ?></div>
    <div class="content">
        <form id="add_user_form" action="<?php echo e(url('users/register')); ?>" class="ui form add-user" method="post" accept-charset="utf-8">
            <?php echo csrf_field(); ?>
            <div class="field">
                <label><?php echo e(__("Employee")); ?></label>
                <select class="ui search dropdown getemail uppercase" name="name">
                    <option value="">Select Employee</option>
                    <?php if(isset($employees)): ?>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?>" data-e="<?php echo e($data->emailaddress); ?>"
                            data-ref="<?php echo e($data->id); ?>"><?php echo e($data->lastname); ?>, <?php echo e($data->firstname); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="field">
                <label><?php echo e(__("Email")); ?></label>
                <input type="text" name="email" class="readonly lowercase" value="" readonly>
            </div>
            <div class="grouped fields opt-radio">
                <label><?php echo e(__("Choose Account type")); ?> </label>
                <div class="field">
                    <div class="ui radio checkbox">
                        <input type="radio" name="acc_type" value="1">
                        <label><?php echo e(__("Employee")); ?></label>
                    </div>
                </div>
                <div class="field" style="padding:0px!important">
                    <div class="ui radio checkbox">
                        <input type="radio" name="acc_type" value="2">
                        <label><?php echo e(__("Admin")); ?></label>
                    </div>
                </div>
            </div>
            <div class="fields">
                <div class="sixteen wide field role">
                    <label for=""><?php echo e(__("Role")); ?></label>
                    <select class="ui dropdown uppercase" name="role_id">
                        <option value="">Select Role</option>
                        <?php if(isset($roles)): ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->role_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="fields">
                <div class="sixteen wide field">
                    <label><?php echo e(__("Status")); ?></label>
                    <select class="ui dropdown uppercase" name="status">
                        <option value="">Select Status</option>
                        <option value="1">Enabled</option>
                        <option value="0">Disabled</option>
                    </select>
                </div>
            </div>
            <div class="two fields">
                <div class="field">
                    <label for=""><?php echo e(__("Password")); ?></label>
                    <input type="password" name="password" class="">
                </div>
                <div class="field">
                    <label for=""><?php echo e(__("Confirm Password")); ?></label>
                    <input type="password" name="password_confirmation" class="">
                </div>
            </div>
            <div class="field">
                <div class="ui error message">
                    <i class="close icon"></i>
                    <div class="header"></div>
                    <ul class="list">
                        <li class=""></li>
                    </ul>
                </div>
            </div>
    </div>
    <div class="actions">
        <input type="hidden" value="" name="ref">
        <button class="ui positive approve small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Register")); ?></button>
        <button class="ui grey cancel small button" type="button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></button>
    </div>
    </form>
</div><?php /**PATH D:\xampp\htdocs\att\final\application\resources\views/admin/modals/modal-add-user.blade.php ENDPATH**/ ?>