<?php $__env->startSection('meta'); ?>
<title>My Settings | Workday Time Clock</title>
<meta name="description" content="Workday my settings">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<script>
    var admin = false;
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h2 class="page-title"><?php echo e(__("General Settings")); ?></h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="box box-success">
                <div class="box-body">
                    <div class="ui secondary blue pointing tabular menu">
                        <a class="item active" data-tab="about"><?php echo e(__("About")); ?></a>
                        <a class="item" data-tab="attribution"><?php echo e(__("Attributions")); ?></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $('.menu .item').tab();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\final\application\resources\views/personal/personal-settings-view.blade.php ENDPATH**/ ?>