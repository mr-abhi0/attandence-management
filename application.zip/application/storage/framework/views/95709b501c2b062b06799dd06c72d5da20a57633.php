    <?php $__env->startSection('meta'); ?>
        <title>Reports | Workday Time Clock</title>
        <meta name="description" content="Workday reports, view reports, and export or download reports.">
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('content'); ?>
    
    <div class="container-fluid">
        <div class="row">
            <h2 class="page-title"><?php echo e(__('Reports')); ?></h2>
        </div>

        <div class="row">
            <div class="box box-success">
                <div class="box-body">
                <table width="100%" class="reports-table table table-striped table-hover" id="dataTables-example" data-order='[[ 0, "asc" ]]'>
                    <thead>
                        <tr>
                            <th><?php echo e(__('Report name')); ?></th>
                            <th class="odd"><?php echo e(__('Last Viewed')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><a href="<?php echo e(url('reports/employee-list')); ?>"><i class="ui icon users"></i> <?php echo e(__('Employee List Report')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 1): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/employee-attendance')); ?>"><i class="ui icon clock"></i> <?php echo e(__('Employee Attendance Report')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 2): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/employee-leaves')); ?>"><i class="ui icon calendar plus"></i> <?php echo e(__('Employee Leaves Report')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 3): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/employee-schedule')); ?>"><i class="ui icon calendar alternate outline"></i> <?php echo e(__('Employee Schedule Report')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 4): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/organization-profile')); ?>"><i class="ui icon chart pie"></i> <?php echo e(__("Organizational Profile")); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 5): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/employee-birthdays')); ?>"><i class="ui icon birthday cake"></i> <?php echo e(__('Employee Birthdays')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 7): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo e(url('reports/user-accounts')); ?>"><i class="ui icon address book outline"></i> <?php echo e(__('User Accounts Report')); ?></a></td>
                            <td class="odd">
                                <?php if(isset($lastviews)): ?>
                                    <?php $__currentLoopData = $lastviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $views): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($views->report_id == 6): ?>
                                            <?php echo e($views->last_viewed); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
    $('#dataTables-example').DataTable({responsive: true,pageLength: 15,lengthChange: false,searching: false,ordering: true});
    </script>
    <?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\server\htdocs\final\application\resources\views/admin/reports.blade.php ENDPATH**/ ?>