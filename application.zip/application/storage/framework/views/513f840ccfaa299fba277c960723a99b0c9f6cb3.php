<div class="ui modal small edit">
    <div class="header"><?php echo e(__("Edit Role")); ?></div>
    <div class="content">
    <form id="edit_role_form" action="<?php echo e(url('users/roles/update')); ?>" class="ui form" method="post" accept-charset="utf-8">
        <?php echo csrf_field(); ?>
        <div class="field">
            <label><?php echo e(__("Role Name")); ?></label>
            <input class="uppercase" name="role_name" value="" type="text">
        </div>
        <div class="field">
            <label><?php echo e(__("Status")); ?></label>
            <select name="state" class="ui dropdown state uppercase">
                <option value="Active"><?php echo e(__("Active")); ?></option>
                <option value="Disabled"><?php echo e(__("Disabled")); ?></option>
            </select>
        </div>
        <div class="field">
            <div class="ui error message">
                <i class="close icon"></i>
                <div class="header"></div>
                <ul class="list">
                    <li class=""></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="actions">
        <input type="hidden" value="" name="id" class="" readonly="">
        <button class="ui positive small button" type="submit" name="submit"><i class="ui checkmark icon"></i> <?php echo e(__("Update")); ?></button>
        <button class="ui grey cancel small button" type="button"><i class="ui times icon"></i> <?php echo e(__("Cancel")); ?></button>
    </div>
    </form>  
</div>
<?php /**PATH C:\server\htdocs\final\application\resources\views/admin/modals/modal-edit-role.blade.php ENDPATH**/ ?>