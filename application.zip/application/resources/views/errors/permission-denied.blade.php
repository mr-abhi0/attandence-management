@extends('layouts.default')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h2>Permission Denied</h2>
            <p>Sorry, you don't have permission to access the page.</p>
        </div>
    </div>
</div>
@endsection
